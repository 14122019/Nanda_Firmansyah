<div class="logo clearfix">
			<div class="float-left mt-3 mb-3">
				<img src="resources/images/logobc.png" alt="Logo Sekolah" width="70px" class="float-left mr-3">
				<div class="float-right">
					<span class="smk">SMK YAJ DEPOK</span><br>
					<span class="visi">Mewujudkan SMK Berkarakter, Berkompeten dan Unggul.</span>
				</div>
			</div>
		</div>