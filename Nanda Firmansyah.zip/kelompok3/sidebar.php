<?php 

$query_artikel_terbaru = mysqli_query($koneksi, "SELECT * FROM tbl_artikel ORDER BY tanggal ASC LIMIT 4");
$query_kategori_artikel= mysqli_query($koneksi, "SELECT * FROM tbl_kategori_artikel LIMIT 4");

?>
<div class="col-sm-4">
	<div class="list-group">
		<span class="list-group-item text-white" style="background-color: #da28d4">Artikel Terbaru</span>
		<?php while($artikel_terbaru = mysqli_fetch_assoc($query_artikel_terbaru)) : ?>
			<a href="detail_artikel.php?id=<?= $artikel_terbaru['id'] ?>" class="list-group-item list-group-item-action"><?= $artikel_terbaru['judul'] ?></a>
		<?php endwhile; ?>
	</div>

	<div class="list-group">
		<span class="list-group-item text-white mt-3" style="background-color: #da28d4">Kategori Artikel</span>
		<?php while($kategori_artikel = mysqli_fetch_assoc($query_kategori_artikel)) : ?>
			<a href="kategori.php?id=<?= $kategori_artikel['id'] ?>" class="list-group-item list-group-item-action"><?= $kategori_artikel['nama_kategori'] ?></a>
		<?php endwhile; ?>
	</div>
	<div class="list-group">
		<span class="list-group-item text-white mt-3" style="background-color: #da28d4">Mitra Industri</span>
		
			<a href="http://bonet.co.id/" target="_blank" ><img src="resources/images/logo-bonet.png"  class="list-group-item list-group-item-action" style="width: 40%" class="list-group-item-action" alt=""></a>
			<a href="https://setiajaya.co.id/" target="_blank" ><img src="resources/images/setiajaya.jpg"  class="list-group-item list-group-item-action" style="width: 40%" class="list-group-item-action" alt=""></a>
</div>
</div>


